// ======================================
// BRAND PRODUCTS VIEW FEATURE
// ======================================

async function viewBrandProducts(brandName) {
  try {
    // 1. Fetch all products
    const res = await fetch('/api/products');
    const json = await res.json();

    const products = (json.data || []).filter(
      p => (p.brand_name || '').toLowerCase() === brandName.toLowerCase()
    );

    openBrandProductsModal(brandName, products);

  } catch (err) {
    console.error(err);
    alert("Failed to load brand products");
  }
}

function openBrandProductsModal(brandName, products) {
  let overlay = document.getElementById('brand-products-overlay');

  if (!overlay) {
    overlay = document.createElement('div');
    overlay.id = 'brand-products-overlay';
    overlay.className = 'pbi-overlay';
    overlay.style.zIndex = '800';

    overlay.onclick = (e) => {
      if (e.target === overlay) closeBrandProductsModal();
    };

    document.body.appendChild(overlay);
  }

  overlay.innerHTML = `
    <div class="pbi-modal" style="max-width:700px;width:95vw;max-height:90vh;display:flex;flex-direction:column">
      
      <div class="pbi-header">
        <div>
          <div style="font-size:18px;font-weight:700">${brandName} Products</div>
          <div style="font-size:12px;color:var(--text3)">
            ${products.length} products found
          </div>
        </div>
        <button class="pbi-close" onclick="closeBrandProductsModal()">✕</button>
      </div>

      <div style="padding:20px;overflow-y:auto;display:flex;flex-direction:column;gap:12px">

        ${products.length === 0 ? `
          <div style="text-align:center;color:var(--text3)">
            No products found for this brand
          </div>
        ` : products.map(p => `
          <div style="border:1px solid var(--border);border-radius:10px;padding:12px;display:flex;gap:12px;align-items:center">
            
            <div style="font-size:24px">${p.icon || '📦'}</div>

            <div style="flex:1">
              <div style="font-weight:600">${p.name}</div>
              <div style="font-size:12px;color:var(--text3)">
                ${p.cat} • ${p.sku}
              </div>
            </div>

            <div style="font-size:12px;color:var(--text2)">
              ${p.stock} units
            </div>

          </div>
        `).join('')}

      </div>

    </div>
  `;

  overlay.style.display = 'flex';
  setTimeout(() => overlay.classList.add('open'), 10);
}

function closeBrandProductsModal() {
  const overlay = document.getElementById('brand-products-overlay');
  if (!overlay) return;

  overlay.classList.remove('open');
  setTimeout(() => overlay.style.display = 'none', 300);
}